# License

Copyright (c) 2019 MJ Rossetti (<prof.mj.rossetti@gmail.com>) and individual student contributor(s).

This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0/>.
